<?php $__env->startSection('content'); ?>

<a class="btn btn-primary" href="<?php echo e(route('wisata.create')); ?>">Add New</a><br><br>

<table class="table table-striped">
<tr>
    <th scope="col">Id</th>
    <th scope="col">Image</th>
    <th scope="col">Nama</th>
    <th scope="col">Kota</th>
    <th scope="col">Harga Tiket</th>
    <th scope="col">Action</th>
</tr>
<?php $__currentLoopData = $wisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($w->id); ?></td>
        <td><img src="<?php echo e(Storage::url('public/images/' . $w->image)); ?>" alt="" style="width: 150px;"></td>
        <td><?php echo e($w->nama); ?></td>
        <td><?php echo e($w->kota); ?></td>
        <td><?php echo e($w->harga_tiket); ?></td>
        <td>
            <a class="btn btn-success" href="<?php echo e(route('wisata.show',$w->id)); ?>">Show</a>
            <a class="btn btn-warning" href="<?php echo e(route('wisata.edit',$w->id)); ?>">Edit</a>

            <form onclick="return confirm('Are you sure?')" action="<?php echo e(route('wisata.destroy',$w->id)); ?>" method="post" style="display: inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger">Delete</button>
            </form>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php echo e($wisata->links()); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata2/resources/views/index.blade.php ENDPATH**/ ?>