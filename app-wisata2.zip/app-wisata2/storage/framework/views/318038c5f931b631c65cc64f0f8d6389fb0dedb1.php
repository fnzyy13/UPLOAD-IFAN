<?php $__env->startSection('content'); ?>

<img src="<?php echo e(Storage::url('public/images/' . $wisatum->image)); ?>" alt="" style="width: 500px;">

<h3><?php echo e($wisatum->nama); ?></h3>
<p>Kota : <?php echo e($wisatum->kota); ?></p>
<p>Harga Tiket : <?php echo e($wisatum->harga_tiket); ?></p>

<a href="<?php echo e(route('wisata.index')); ?>" class="btn btn-secondary">Back to Index</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata2/resources/views/show.blade.php ENDPATH**/ ?>