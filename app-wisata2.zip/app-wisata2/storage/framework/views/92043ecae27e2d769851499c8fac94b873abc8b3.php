<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('wisata.update',$wisatum->id)); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

<label for="">Nama</label><br>
<input type="text" name="nama" id="" value="<?php echo e($wisatum->nama); ?>"><br><br>

<label for="">Kota</label><br>
<input type="text" name="kota" id="" value="<?php echo e($wisatum->kota); ?>"><br><br>

<label for="">Harga Tiket</label>
<input type="number" name="harga_tiket" id="" value="<?php echo e($wisatum->harga_tiket); ?>"><br><br>

<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Update" class="btn btn-primary">

</form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app-wisata2/resources/views/edit.blade.php ENDPATH**/ ?>