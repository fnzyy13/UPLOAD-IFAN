@extends('layout')

@section('content')

<img src="{{ Storage::url('public/images/' . $wisatum->image) }}" alt="" style="width: 500px;">

<h3>{{ $wisatum->nama }}</h3>
<p>Kota : {{ $wisatum->kota }}</p>
<p>Harga Tiket : {{ $wisatum->harga_tiket }}</p>

<a href="{{route('wisata.index')}}" class="btn btn-secondary">Back to Index</a>
@endsection