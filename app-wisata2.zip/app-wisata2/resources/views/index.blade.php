@extends('layout')

@section('content')

<a class="btn btn-primary" href="{{route('wisata.create')}}">Add New</a><br><br>

<table class="table table-striped">
<tr>
    <th scope="col">Id</th>
    <th scope="col">Image</th>
    <th scope="col">Nama</th>
    <th scope="col">Kota</th>
    <th scope="col">Harga Tiket</th>
    <th scope="col">Action</th>
</tr>
@foreach ($wisata as $w)
    <tr>
        <td>{{ $w->id }}</td>
        <td><img src="{{ Storage::url('public/images/' . $w->image) }}" alt="" style="width: 150px;"></td>
        <td>{{ $w->nama }}</td>
        <td>{{ $w->kota }}</td>
        <td>{{ $w->harga_tiket }}</td>
        <td>
            <a class="btn btn-success" href="{{route('wisata.show',$w->id)}}">Show</a>
            <a class="btn btn-warning" href="{{route('wisata.edit',$w->id)}}">Edit</a>

            <form onclick="return confirm('Are you sure?')" action="{{route('wisata.destroy',$w->id)}}" method="post" style="display: inline;">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger">Delete</button>
            </form>
        </td>
    </tr>
@endforeach

</table>

{{ $wisata->links() }}
    
@endsection