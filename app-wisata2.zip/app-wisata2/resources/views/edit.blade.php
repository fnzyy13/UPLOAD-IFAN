@extends('layout')

@section('content')

<form action="{{route('wisata.update',$wisatum->id)}}" method="post" enctype="multipart/form-data">
@csrf
@method('PUT')

<label for="">Nama</label><br>
<input type="text" name="nama" id="" value="{{ $wisatum->nama }}"><br><br>

<label for="">Kota</label><br>
<input type="text" name="kota" id="" value="{{ $wisatum->kota }}"><br><br>

<label for="">Harga Tiket</label><br>
<input type="number" name="harga_tiket" id="" value="{{ $wisatum->harga_tiket }}"><br><br>

<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Update" class="btn btn-primary">

</form>
    
@endsection