@extends('layout')

@section('content')

<form class="form" action="{{route('wisata.store')}}" method="post" enctype="multipart/form-data">
@csrf

<label for="">Masukkan Nama :</label><br>
<input type="text" name="nama" id=""><br><br>

<label for="">Masukkan Kota :</label><br>
<input type="text" name="kota" id=""><br><br>

<label for="">Masukkan Harga Tiket :</label><br>
<input type="number" name="harga_tiket" id=""><br><br>

<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Save" class="btn btn-primary">

</form>
    
@endsection