<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Wisata;
use Illuminate\Support\Facades\Storage;

class WisataController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $wisata = Wisata::paginate(5);
        return view('index')->with(['wisata' => $wisata]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'kota' => 'required',
            'harga_tiket' => 'required',
            'image' => 'required|image|mimes:jpg,jpeg,png,gif|max:2048'
        ]);

        $image = $request->file('image');
        $image->storeAs('public/images/', $image->hashName());

        Wisata::create([
            'nama' => $request->nama,
            'kota' => $request->kota,
            'harga_tiket' => $request->harga_tiket,
            'image' => $image->hashName(),
        ]);

        return redirect()->route('wisata.index')
        ->with('s', 'Wisata added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Wisata $wisatum)
    {
        return view('show')->with(['wisatum' => $wisatum]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Wisata $wisatum)
    {
        return view('edit')->with(['wisatum' => $wisatum]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,Wisata $wisatum)
    {
            //validasi
       $request->validate([
        'nama' => 'required',
        'kota' => 'required',
        'harga_tiket' => 'required',
    ]);

        if ($request->has('image')) {
            $image = $request->file('image');
            $image->storeAs('public/images/', $image->hashName());

            Storage::delete('public/images/' . $wisatum->image);

    $wisatum->update([
            'nama' => $request->nama,
            'kota' => $request->kota,
            'harga_tiket' => $request->harga_tiket,
            'image' => $image->hashName(),
    ]);

    } else {
    $wisatum->update([
        'nama' => $request->nama,
        'kota' => $request->kota,
        'harga_tiket' => $request->harga_tiket,
    ]);
}

    return redirect()->route('wisata.index')
    ->with('s', 'Wisata updated successfully');
    }
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Wisata $wisatum)
    {

        Storage::delete('public/images/' . $wisatum->image);

        $wisatum->delete();

        return redirect()->route('wisata.index')
        ->with('s', 'wisata deleted successfully');
    }
}
